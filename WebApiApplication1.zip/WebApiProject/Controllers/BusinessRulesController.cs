﻿
using System.IO;
using WebApiProject.Models;
using System.Xml;
using System.Xml.Serialization;
using Newtonsoft.Json;
using System.Web.Http;
using System.Collections.Generic;
using Helpers;
using System.Configuration;
using System;
using System.Globalization;

namespace WebApiProject.Controllers
{
    public class BusinessRulesController : ApiController
    {
        [HttpPost]
        [Route("api/Upsert")]
        public ResponseContainer<bool> Upsert([FromBody]BusinessRulesContainer dataContainer)
        {
            string folderPath = ConfigurationManager.AppSettings["DestinationFolder"];
            ResponseContainer<bool> res = new ResponseContainer<bool>();
            dataContainer.FileName = MyHelper.GetFileNameWithExtension(dataContainer.FileName);
            string fullFilePath = $"{folderPath}{dataContainer.FileName}";
            if (File.Exists(fullFilePath))
            {
                MyHelper.MoveFileToBkpFolder(fullFilePath, dataContainer.FileName);
            }
            var resultXml = MyHelper.GetXmlFromProfileData(dataContainer.DataContainer);

            if (!string.IsNullOrEmpty(resultXml) && !File.Exists(fullFilePath))
            {
                MyHelper.SaveXmlFileToFolder(resultXml, fullFilePath);
                res.Data = true;
            }
            else
            {
                res.Data = false;
            }
            return res;
        }

        [HttpGet]
        [Route("api/Get")]
        public ResponseContainer<BusinessRulesContainer> Get(string fileName)
        {
            ResponseContainer<BusinessRulesContainer> res = new ResponseContainer<BusinessRulesContainer>();
            string folderPath = ConfigurationManager.AppSettings["DestinationFolder"];
            string fullFilePath = $"{folderPath}{MyHelper.GetFileNameWithExtension(fileName)}";

            if (!File.Exists(fullFilePath))
            {
                return res;         
            }
            string xml = File.ReadAllText(fullFilePath);
            var recoProfile1 = xml.ParseXML<RecoProfile>();
            res.Data.DataContainer = JsonConvert.SerializeObject(recoProfile1);
            res.Data.FileName = fileName;
            return res;
        }

    }
}