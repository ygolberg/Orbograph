﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
// NOTE: Generated code may require at least .NET Framework 4.5 or .NET Core/Standard 2.0.
/// <remarks/>
[System.SerializableAttribute()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
[System.Xml.Serialization.XmlRootAttribute(Namespace = "", IsNullable = false)]
public partial class RecoProfile
{

    private RecoProfileRecoTest[] testsField;

    private RecoProfileMetaData metaDataField;

    private string descriptionField;

    private int resultThresholdField;

    private int testMinAmountField;

    /// <remarks/>
    [System.Xml.Serialization.XmlArrayItemAttribute("RecoTest", IsNullable = false)]
    public RecoProfileRecoTest[] Tests
    {
        get
        {
            return this.testsField;
        }
        set
        {
            this.testsField = value;
        }
    }

    /// <remarks/>
    public RecoProfileMetaData MetaData
    {
        get
        {
            return this.metaDataField;
        }
        set
        {
            this.metaDataField = value;
        }
    }

    /// <remarks/>
    [System.Xml.Serialization.XmlAttributeAttribute()]
    public string Description
    {
        get
        {
            return this.descriptionField;
        }
        set
        {
            this.descriptionField = value;
        }
    }

    /// <remarks/>
    [System.Xml.Serialization.XmlAttributeAttribute()]
    public int ResultThreshold
    {
        get
        {
            return this.resultThresholdField;
        }
        set
        {
            this.resultThresholdField = value;
        }
    }

    /// <remarks/>
    [System.Xml.Serialization.XmlAttributeAttribute()]
    public int TestMinAmount
    {
        get
        {
            return this.testMinAmountField;
        }
        set
        {
            this.testMinAmountField = value;
        }
    }
}

/// <remarks/>
[System.SerializableAttribute()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
public partial class RecoProfileRecoTest
{

    private string typeField;

    private bool requiredField;

    private ushort thresholdField;

    private int minTestAmountField;

    private decimal weightField;

    /// <remarks/>
    [System.Xml.Serialization.XmlAttributeAttribute()]
    public string Type
    {
        get
        {
            return this.typeField;
        }
        set
        {
            this.typeField = value;
        }
    }

    /// <remarks/>
    [System.Xml.Serialization.XmlAttributeAttribute()]
    public bool Required
    {
        get
        {
            return this.requiredField;
        }
        set
        {
            this.requiredField = value;
        }
    }

    /// <remarks/>
    [System.Xml.Serialization.XmlAttributeAttribute()]
    public ushort Threshold
    {
        get
        {
            return this.thresholdField;
        }
        set
        {
            this.thresholdField = value;
        }
    }

    /// <remarks/>
    [System.Xml.Serialization.XmlAttributeAttribute()]
    public int MinTestAmount
    {
        get
        {
            return this.minTestAmountField;
        }
        set
        {
            this.minTestAmountField = value;
        }
    }

    /// <remarks/>
    [System.Xml.Serialization.XmlAttributeAttribute()]
    public decimal Weight
    {
        get
        {
            return this.weightField;
        }
        set
        {
            this.weightField = value;
        }
    }
}

/// <remarks/>
[System.SerializableAttribute()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
public partial class RecoProfileMetaData
{

    private RecoProfileMetaDataDocumentType[] allowedDocTypesField;

    private RecoProfileMetaDataValidPeriod validPeriodField;

    private int newAccountPeriodField;

    private RecoProfileMetaDataListType[] payerBlackListsField;

    private RecoProfileMetaDataListType1[] accountBlackListsField;

    /// <remarks/>
    [System.Xml.Serialization.XmlArrayItemAttribute("DocumentType", IsNullable = false)]
    public RecoProfileMetaDataDocumentType[] AllowedDocTypes
    {
        get
        {
            return this.allowedDocTypesField;
        }
        set
        {
            this.allowedDocTypesField = value;
        }
    }

    /// <remarks/>
    public RecoProfileMetaDataValidPeriod ValidPeriod
    {
        get
        {
            return this.validPeriodField;
        }
        set
        {
            this.validPeriodField = value;
        }
    }

    /// <remarks/>
    public int NewAccountPeriod
    {
        get
        {
            return this.newAccountPeriodField;
        }
        set
        {
            this.newAccountPeriodField = value;
        }
    }

    /// <remarks/>
    [System.Xml.Serialization.XmlArrayItemAttribute("ListType", IsNullable = false)]
    public RecoProfileMetaDataListType[] PayerBlackLists
    {
        get
        {
            return this.payerBlackListsField;
        }
        set
        {
            this.payerBlackListsField = value;
        }
    }

    /// <remarks/>
    [System.Xml.Serialization.XmlArrayItemAttribute("ListType", IsNullable = false)]
    public RecoProfileMetaDataListType1[] AccountBlackLists
    {
        get
        {
            return this.accountBlackListsField;
        }
        set
        {
            this.accountBlackListsField = value;
        }
    }
}

/// <remarks/>
[System.SerializableAttribute()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
public partial class RecoProfileMetaDataDocumentType
{

    private string typeField;

    private bool requiredField;

    /// <remarks/>
    [System.Xml.Serialization.XmlAttributeAttribute()]
    public string Type
    {
        get
        {
            return this.typeField;
        }
        set
        {
            this.typeField = value;
        }
    }

    /// <remarks/>
    [System.Xml.Serialization.XmlAttributeAttribute()]
    public bool Required
    {
        get
        {
            return this.requiredField;
        }
        set
        {
            this.requiredField = value;
        }
    }
}

/// <remarks/>
[System.SerializableAttribute()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
public partial class RecoProfileMetaDataValidPeriod
{

    private int daysBackwardField;

    private int daysForwardField;

    /// <remarks/>
    [System.Xml.Serialization.XmlAttributeAttribute()]
    public int DaysBackward
    {
        get
        {
            return this.daysBackwardField;
        }
        set
        {
            this.daysBackwardField = value;
        }
    }

    /// <remarks/>
    [System.Xml.Serialization.XmlAttributeAttribute()]
    public int DaysForward
    {
        get
        {
            return this.daysForwardField;
        }
        set
        {
            this.daysForwardField = value;
        }
    }
}

/// <remarks/>
[System.SerializableAttribute()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
public partial class RecoProfileMetaDataListType
{

    private string nameField;

    private bool requiredField;

    /// <remarks/>
    [System.Xml.Serialization.XmlAttributeAttribute()]
    public string Name
    {
        get
        {
            return this.nameField;
        }
        set
        {
            this.nameField = value;
        }
    }

    /// <remarks/>
    [System.Xml.Serialization.XmlAttributeAttribute()]
    public bool Required
    {
        get
        {
            return this.requiredField;
        }
        set
        {
            this.requiredField = value;
        }
    }
}

/// <remarks/>
[System.SerializableAttribute()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
public partial class RecoProfileMetaDataListType1
{

    private string nameField;

    private bool requiredField;

    /// <remarks/>
    [System.Xml.Serialization.XmlAttributeAttribute()]
    public string Name
    {
        get
        {
            return this.nameField;
        }
        set
        {
            this.nameField = value;
        }
    }

    /// <remarks/>
    [System.Xml.Serialization.XmlAttributeAttribute()]
    public bool Required
    {
        get
        {
            return this.requiredField;
        }
        set
        {
            this.requiredField = value;
        }
    }
}


