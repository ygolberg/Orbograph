﻿using System;
using System.Configuration;
using System.Globalization;
using System.IO;
using System.Text;
using System.Web.Script.Serialization; // Add reference: System.Web.Extensions
using System.Xml;
using System.Xml.Serialization;

namespace Helpers
{
    internal static class MyHelper
    {
        private static JavaScriptSerializer json;
        private static JavaScriptSerializer JSON { get { return json ?? (json = new JavaScriptSerializer()); } }

        public static Stream ToStream(this string @this)
        {
            var stream = new MemoryStream();
            var writer = new StreamWriter(stream);
            writer.Write(@this);
            writer.Flush();
            stream.Position = 0;
            return stream;
        }


        public static T ParseXML<T>(this string @this) where T : class
        {
            var reader = XmlReader.Create(@this.Trim().ToStream(), new XmlReaderSettings() { ConformanceLevel = ConformanceLevel.Document });
            return new XmlSerializer(typeof(T)).Deserialize(reader) as T;
        }

        public static T ParseJSON<T>(this string @this) where T : class
        {
            return JSON.Deserialize<T>(@this.Trim());
        }

        public static void MoveFileToBkpFolder(string fullFilePath, string FileName)
        {
            string bkpFolderPath = ConfigurationManager.AppSettings["BkpFolder"];
            string date = DateTime.Now.ToString("s", DateTimeFormatInfo.InvariantInfo).Replace("-", "").Replace("T", "").Replace(":", "").Trim();
            string[] fileNameData = FileName.Split('.');
            string bkpFullFilePath = $"{bkpFolderPath}{fileNameData[0]}_{date}.{fileNameData[1]}";
            File.Move(fullFilePath, bkpFullFilePath);
        }

        public static string GetXmlFromProfileData(string DataContainer)
        {
            string json = DataContainer;
            var rProfile = json.ParseJSON<RecoProfile>();

            XmlSerializer xsSubmit = new XmlSerializer(typeof(RecoProfile));
            var resultXml = "";
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;            
            settings.Encoding = Encoding.UTF8;

            using (var sww = new StringWriter())
            {
                using (XmlWriter writer = XmlWriter.Create(sww, settings))
                {
                    writer.WriteProcessingInstruction("xml", "version='1.0' encoding='utf-8'");
                    xsSubmit.Serialize(writer, rProfile);
                    resultXml = sww.ToString();
                }
            }
            return resultXml;
        }

        public static void SaveXmlFileToFolder(string resultXml, string fullFilePath)
        {
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(resultXml);
            if (fullFilePath.IndexOf(".xml") > 0)
            {
                doc.Save(fullFilePath);
            }
            else
            {
                doc.Save(fullFilePath + @".xml");
            }
        }

        public static string GetFileNameWithExtension(string FileName)
        {
            if (FileName.IndexOf(".xml") > 0)
            {
                return FileName;
            }
            else
            {
                return FileName + @".xml";
            }
        }
    }
}