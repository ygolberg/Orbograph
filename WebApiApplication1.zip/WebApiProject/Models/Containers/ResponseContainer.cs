﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace WebApiProject.Models
{
    [DataContract]    
    public class ResponseContainer<T>
    {
        [DataMember]
        public Status ResponseCode { get; set; }
        [DataMember]
        public List<ErrorContainer> Errors { get; set; }
        [DataMember]
        public T Data { get; set; }

        public ResponseContainer()
        {
            Data = Activator.CreateInstance<T>();
            ResponseCode = Status.Success;
            Errors = new List<ErrorContainer>();
        }
    }
    [DataContract]
    public enum Status
    {
        [EnumMember(Value = "0")]
        Success = 0,
        [EnumMember(Value = "1")]
        Error = 1,
        [EnumMember(Value = "2")]
        Warning = 2
    }
    [DataContract]
    public class ErrorContainer
    {
        [DataMember]
        public int ErrorCode { get; set; }
        [DataMember]
        public string Message { get; set; }

        public ErrorContainer() { }

        public ErrorContainer(int code, string message)
        {
            this.ErrorCode = code;
            this.Message = message;
        }

    }
}