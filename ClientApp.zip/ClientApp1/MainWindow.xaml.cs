﻿using ClientApp1.Models;
using ClientApp1.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace ClientApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public ObservableCollection<RecoProfileRecoTest> tests { get; set; }
        public bool DataWasChanged = false;

        public MainWindow()
        {
            InitializeComponent();
            CallWebApiServices service = new CallWebApiServices();
            RecoProfile getRulesResult = service.GetRules("Default.xml");
            if (getRulesResult != null)
            {
                LoadData(getRulesResult);
            }
            
        }

        private void LoadButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!String.IsNullOrEmpty(txtFileName.Text))
                {
                    CallWebApiServices service = new CallWebApiServices();
                    RecoProfile getRulesResult = service.GetRules(txtFileName.Text);// ("FirstTest.xml");
                    if (getRulesResult != null)
                    {
                        LoadData(getRulesResult);                                               
                    }
                }
                return;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if(String.IsNullOrEmpty(txtFileName.Text))
                {
                    MessageBox.Show("File name was not set. Please enter file name.");
                    return;
                }
                CallWebApiServices service = new CallWebApiServices();
                if (DataWasChanged)
                {
                    bool dataWasSaved = service.UpsertFile(txtFileName.Text, GetDataFromForm());
                    if (dataWasSaved)
                    {
                        DataWasChanged = false;
                        MessageBox.Show("Data was uploaded successfully");
                    }
                    else
                    {
                        MessageBox.Show("There was a problem to save the data");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        public RecoProfile GetDataFromForm()
        {
            RecoProfile getRulesResult = new RecoProfile();
            getRulesResult.MetaData = new RecoProfileMetaData();
            getRulesResult.MetaData.ValidPeriod = new RecoProfileMetaDataValidPeriod();
            if (!String.IsNullOrEmpty(txtValidDatesRangePast.Text))
            {
                getRulesResult.MetaData.ValidPeriod.DaysBackward = Convert.ToInt32(txtValidDatesRangePast.Text);
            }
            if (!String.IsNullOrEmpty(txtValidDatesRangeFuture.Text))
            {
                getRulesResult.MetaData.ValidPeriod.DaysForward = Convert.ToInt32(txtValidDatesRangeFuture.Text);
            }
            if (!String.IsNullOrEmpty(txtDaysForNewAccount.Text))
            {
                getRulesResult.MetaData.NewAccountPeriod = Convert.ToInt32(txtDaysForNewAccount.Text);
            }
            SetAllowedDocTypes(getRulesResult.MetaData);

            SetTestsData(getRulesResult);

            return getRulesResult;
        }

        private void SetTestsData(RecoProfile getRulesResult)
        {
            RecoProfileRecoTest[] tests = new RecoProfileRecoTest[lvTests.Items.Count];
            getRulesResult.Tests = new RecoProfileRecoTest[lvTests.Items.Count];

            List<RecoProfileRecoTest> testFields = lvTests.Items.OfType<RecoProfileRecoTest>().ToList();

            int i = 0;
            testFields.ForEach(x => {
                RecoProfileRecoTest test = new RecoProfileRecoTest()
                {
                    MinTestAmount = x.MinTestAmount,
                    Required = x.Required,
                    Threshold =x.Threshold,
                    Type = x.Type,
                    Weight = x.Weight
                };
                getRulesResult.Tests[i] = test;
                i++;
            });
        }

        public void SetAllowedDocTypes(RecoProfileMetaData MetaData)
        {
            MetaData.AllowedDocTypes = new RecoProfileMetaDataDocumentType[4];
            int i = 0;
            RecoProfileMetaDataDocumentType docType = new RecoProfileMetaDataDocumentType()
            {
                Required = cBxBusinessCheck.IsChecked.Value,
                Type = "Business Check"
            };
            MetaData.AllowedDocTypes[i] = docType;
            i++;
            docType = new RecoProfileMetaDataDocumentType()
            {
                Required = cBxPersonalCheck.IsChecked.Value,
                Type = "Personal Check"
            };
            MetaData.AllowedDocTypes[i] = docType;
            i++;
            docType = new RecoProfileMetaDataDocumentType()
            {
                Required = cBxMoneyOrder.IsChecked.Value,
                Type = "Money Order"
            };
            MetaData.AllowedDocTypes[i] = docType;
            i++;
            docType = new RecoProfileMetaDataDocumentType()
            {
                Required = cBxTravelersCheck.IsChecked.Value,
                Type = "Traveler's Check"
            };
            MetaData.AllowedDocTypes[i] = docType;
        }

        public void LoadData(RecoProfile getRulesResult)
        {
            txtValidDatesRangePast.Text = getRulesResult.MetaData?.ValidPeriod?.DaysBackward.ToString();
            txtValidDatesRangeFuture.Text = getRulesResult.MetaData?.ValidPeriod?.DaysForward.ToString();
            txtDaysForNewAccount.Text = getRulesResult.MetaData?.NewAccountPeriod.ToString();

            if (getRulesResult.MetaData.AllowedDocTypes != null)
            {
                foreach (RecoProfileMetaDataDocumentType docType in getRulesResult.MetaData.AllowedDocTypes)
                {
                    switch (docType.Type)
                    {
                        case "Business Check":
                            cBxBusinessCheck.IsChecked = docType.Required;
                            break;
                        case "Personal Check":
                            cBxPersonalCheck.IsChecked = docType.Required;
                            break;
                        case "Money Order":
                            cBxMoneyOrder.IsChecked = docType.Required;
                            break;
                        case "Traveler's Check":
                            cBxTravelersCheck.IsChecked = docType.Required;
                            break;
                    }
                }


            }
            if (getRulesResult.MetaData.PayerBlackLists != null)
            {
                foreach (RecoProfileMetaDataListType payer in getRulesResult.MetaData.PayerBlackLists)
                {
                    switch (payer.Name)
                    {
                        case "PayerBlackList":
                            cBxBlackList.IsChecked = payer.Required;
                            break;
                        case "PayerWhiteList":
                            cBxWhiteList.IsChecked = payer.Required;
                            break;
                    }
                }
            }
            if (getRulesResult.MetaData.AccountBlackLists != null)
            {
                foreach (RecoProfileMetaDataListType1 payer in getRulesResult.MetaData.AccountBlackLists)
                {
                    switch (payer.Name)
                    {
                        case "AccountBlackLists":
                            cBxBlockedAccounts.IsChecked = payer.Required;
                            break;
                        case "AccountWhiteList":
                            cBxSuspiciousList.IsChecked = payer.Required;
                            break;
                    }
                }
            }

            if (getRulesResult.Tests != null && getRulesResult.Tests.Length > 0)
            {
                ObservableCollection<RecoProfileRecoTest> tests = new ObservableCollection<RecoProfileRecoTest>();
                foreach (RecoProfileRecoTest test in getRulesResult.Tests)
                {
                    tests = GetTests(getRulesResult);
                }
                if (tests.Count > 0)
                {
                    lvTests.ItemsSource = tests;
                }
            }
            DataWasChanged = false;
        }

        public ObservableCollection<RecoProfileRecoTest> GetTests(RecoProfile getRulesResult)
        {
            ObservableCollection<RecoProfileRecoTest> tests = new ObservableCollection<RecoProfileRecoTest>();
            double totalThreshold = 0;
            decimal totalMinAmount = 0;
            foreach (RecoProfileRecoTest test in getRulesResult.Tests)
            {
                totalThreshold += test.Threshold;
                totalMinAmount += test.MinTestAmount;
                tests.Add(test);
            }
            txtMinimumAmmountTotal.Text = totalMinAmount.ToString();
            txtTotalThreshold.Text = totalThreshold.ToString();
            slTotalThresHold.Value = totalThreshold;
            return tests;
        }

        private void txtThreshold_TextChanged(object sender, TextChangedEventArgs e)
        {            
            CalculateTotalThreshold();
        }

        private void CalculateMinimumAmmount()
        {
            int minAmount = 0;
            List<RecoProfileRecoTest> testFields = lvTests.Items.OfType<RecoProfileRecoTest>().ToList();

            testFields.ForEach(x => {
                minAmount += x.MinTestAmount;
            });
            txtMinimumAmmountTotal.Text = minAmount.ToString();
            txtMinimumAmmountTotal.UpdateLayout();
        }

        private void CalculateTotalThreshold()
        {
            double threshold = 0;

            List<RecoProfileRecoTest> testFields = lvTests.Items.OfType<RecoProfileRecoTest>().ToList();

            testFields.ForEach(x => {
                threshold += Convert.ToDouble(x.Threshold);
            });
            txtTotalThreshold.Text = threshold.ToString();
            txtTotalThreshold.UpdateLayout();
            slTotalThresHold.Value = threshold;
        }


        private void TextBox_MouseLeave(object sender, MouseEventArgs e)
        {
            CalculateTotalThreshold();
        }
        private void txtxMinimumAccount_MouseLeave(object sender, MouseEventArgs e)
        {
            CalculateMinimumAmmount();
        }

        private void txtMinimumAmmount_TextChanged(object sender, TextChangedEventArgs e)
        {
            var textBox = sender as TextBox;
            CalculateMinimumAmmount();
        }

        private void txtValidDatesRangePast_TextChanged(object sender, TextChangedEventArgs e)
        {            
            if (!DataWasChanged && ((System.Windows.Controls.TextBox)sender).IsFocused)
            {
                DataWasChanged = true;
            }
        }

        private void cBx_Click(object sender, RoutedEventArgs e)
        {
            if (!DataWasChanged)
            {
                DataWasChanged = true;
            }
        }
        private void cBxList_Click(object sender, RoutedEventArgs e)
        {
            if (!DataWasChanged)
            {
                DataWasChanged = true;
            }
        }


    }
}
