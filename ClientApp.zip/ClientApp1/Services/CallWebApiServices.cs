﻿using ClientApp1.Models;
using Helpers;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using WebApiProject.Models;

namespace ClientApp1.Services
{
    public class CallWebApiServices
    {
        public RecoProfile GetRules(string fileName)
        {
            string baseUri = ConfigurationManager.AppSettings["uri"];
            RecoProfile getRulesResult = null;
            using (var client = new HttpClient())
            {                
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.BaseAddress = new Uri(baseUri);
                
                var responseTask = client.GetAsync(string.Format("get?fileName={0}", fileName));
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();
                    var rules = JsonConvert.DeserializeObject<ResponseContainer<BusinessRulesContainer>>(readTask.Result);
                    if(rules != null && !String.IsNullOrEmpty(rules.Data.DataContainer))
                    {
                        string json = rules.Data.DataContainer;
                        getRulesResult = json.ParseJSON<RecoProfile>();
                    }
                }
            }
            return getRulesResult;
        }
        public bool UpsertFile(string fileName, RecoProfile profileRule)
        {
            string baseUri = ConfigurationManager.AppSettings["uri"];
            bool upsertResult = false;
            using (var client = new HttpClient())
            {                
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.BaseAddress = new Uri(baseUri);
                
                BusinessRulesContainer dataContainer = new BusinessRulesContainer();
                dataContainer.FileName = fileName;
                dataContainer.DataContainer = JsonConvert.SerializeObject(profileRule);

                var content = new StringContent(JsonConvert.SerializeObject(dataContainer), Encoding.UTF8, "application/json");
                var postTask = client.PostAsync("Upsert", content);
                postTask.Wait();

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var upsertedFile = JsonConvert.DeserializeObject<ResponseContainer<bool>>(readTask.Result);                  
                    if(upsertedFile != null)
                    {
                        upsertResult = upsertedFile.Data;
                    }
                }
                else
                {
                    //MessageBox.Show(result.StatusCode.ToString());
                    upsertResult = false;
                }
            }
            return upsertResult;
        }
    }
}
